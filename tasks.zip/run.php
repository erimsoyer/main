<?php
include 'class.php';

echo "<h2>Collatz Conjecture (3x + 1)</h2>";

$rangeStart = 50; // start value
$rangeEnd = 1551; // end value

$collatzProcessor = new Collatz($rangeStart, $rangeEnd); 

// Process range and get statistics
$collatzProcessor->processRange();
$statistics = $collatzProcessor->getStatistics();

echo "<strong>Our range:</strong> $rangeStart to $rangeEnd <br><br>";

if ($statistics) {
    echo "<strong>Statistics:</strong><br>";
    echo "Num with min iterations: " . $statistics['minIterations']['number'] . 
         " (" . $statistics['minIterations']['iterations'] . " steps)<br>";
    echo "Num with max iterations: " . $statistics['maxIterations']['number'] . 
         " (" . $statistics['maxIterations']['iterations'] . " steps)<br>";
    echo "Num with peak highest value: " . $statistics['maxPeakValue']['number'] . 
         " (Peak value: " . $statistics['maxPeakValue']['peakValue'] . ")<br>";
} else {
    echo "No statistics available. Please ensure you have processed a valid range.";
}
?>
